import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Font;
import java.sql.*;
import javax.swing.table.*;
import java.util.Vector;
import java.awt.print.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.awt.JobAttributes;
import java.awt.geom.Line2D;
import javax.swing.JOptionPane; 

import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.*;
import java.util.Iterator;


import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
public class tos19{

  public static void main(String[] args) {
    
    JFrame frame = new JFrame("CuricsoftdevelopmentTECH");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


JPanel panel = new JPanel();
      panel.setBackground(Color.gray);
     GridLayout layout = new GridLayout(6,1);
      layout.setHgap(10);
      layout.setVgap(10);
      
      panel.setLayout(layout);

JButton buton1=new JButton("BLAGAJNAX");        
      JButton buton2=new JButton("SKLADISTE"); 
      JButton buton3=new JButton("PRIMKA"); 
      JButton buton4=new JButton("SKLADISNICA");
      JButton buton5=new JButton("DJELATNICI");
      JButton buton6=new JButton("IZLAZ");
    
    panel.add(buton1);
    panel.add(buton2);
    panel.add(buton3);
    panel.add(buton4);
    panel.add(buton5);
    panel.add(buton6);

buton1.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 new blagajnax();
  }
  }); 
buton2.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 new skladiste();
  }
  }); 
buton3.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 new primka();
  }
  }); 


buton4.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 new skladisnica();
  }
  }); 

buton5.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 new djelatnici();
  }
  }); 


buton6.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 System.exit(0);
  }
  }); 

frame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
            System.exit(0);
         }        
      });    





frame.add(panel);
  
    frame.setSize(300,200);
    frame.setVisible(true);
  }
}
/////////////////////////////////////////////////////////////////////////blagajnax

class blagajnax {
JFrame blagajnax;
JPanel panel;
JLabel ime,zaporka;
JTextField txtime,txtzaporka;
JButton potvrdi,odustani;
public blagajnax()
{
blagajnax=new JFrame("zaporka");

panel = new JPanel();
panel.setBackground(Color.gray);
GridLayout layout = new GridLayout(3,2,30,20);
panel.setLayout(layout);
Font myFont = new Font("Serif", Font.ITALIC | Font.BOLD, 16);
panel.setFont(myFont);

ime=new JLabel("Unesi ime");ime.setFont(myFont);
txtime=new JTextField(15);txtime.setFont(myFont);
zaporka=new JLabel("Unesi zaporka");zaporka.setFont(myFont);
txtzaporka=new JTextField(15);txtzaporka.setFont(myFont);

potvrdi=new JButton("Potvrdi");potvrdi.setFont(myFont);
odustani=new JButton("odustani");odustani.setFont(myFont);
panel.add(ime);
panel.add(txtime);
panel.add(zaporka);
panel.add(txtzaporka);




panel.add(potvrdi);
panel.add(odustani);



blagajnax.add(panel);
blagajnax.setSize(400,200);
blagajnax.setVisible(true);



odustani.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
  blagajnax.dispose();
  }
  }); 

potvrdi.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 potvrdi();
  }
  }); 

blagajnax.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
           blagajnax.dispose();
         }        
      });   
}



public  void potvrdi()
{

Connection c = null;
    Statement stmt = null;
String txtimex=txtime.getText().toString();
String txtzaporkax=txtzaporka.getText().toString();
 try {
      Class.forName("org.sqlite.JDBC");
      c = DriverManager.getConnection("jdbc:sqlite:basa.db");
      
      System.out.println("Opened database successfully");

      stmt = c.createStatement();

String str="SELECT * FROM djelatnici where ime='"+txtimex+"' and zaporka='"+txtzaporkax+"';";

ResultSet rs = stmt.executeQuery(str);
rs.next();
String[] t=new String[5];
t[0]=rs.getString(1);
t[1]=rs.getString(2);
t[2]=rs.getString(3);
t[3]=rs.getString(4);
t[4]=rs.getString(5);

System.out.println(t[0]+" "+t[1]+" "+t[2]+" "+t[3]+" "+t[4]);


new blagajna(t[2],t[3],Integer.parseInt(t[0]));


stmt.close();
     
      c.close();
    } catch ( Exception e ) {
      System.err.println( e.getMessage() );
     JOptionPane.showMessageDialog(blagajnax, "Pogreska sa zaporkom");
//System.exit(0);
    }
    System.out.println("Records created successfully");
  }


}

/////////////////////////////////////////////////////////////////////////primka

class primka {
JFrame primka;
JPanel panel;
JLabel sifra,artikl,mjera,kolicina,pdv,cijena;
JTextField txtsifra,txtartikl,txtmjera,txtkolicina,txtpdv,txtcijena;
JButton potvrdi,odustani;
public primka()
{
primka=new JFrame("primka");

panel = new JPanel();
panel.setBackground(Color.gray);
GridLayout layout = new GridLayout(7,2,30,20);
panel.setLayout(layout);
Font myFont = new Font("Serif", Font.ITALIC | Font.BOLD, 16);
panel.setFont(myFont);

sifra=new JLabel("Unesi sifru");sifra.setFont(myFont);
txtsifra=new JTextField(15);txtsifra.setFont(myFont);
artikl=new JLabel("Unesi artikl");artikl.setFont(myFont);
txtartikl=new JTextField(15);txtartikl.setFont(myFont);
mjera=new JLabel("Unesi mjeru");mjera.setFont(myFont);
txtmjera=new JTextField(15);txtmjera.setFont(myFont);
kolicina=new JLabel("Unesi kolicinu");kolicina.setFont(myFont);
txtkolicina=new JTextField(15);txtkolicina.setFont(myFont);
pdv=new JLabel("Unesi pdv");pdv.setFont(myFont);
txtpdv=new JTextField(15);txtpdv.setFont(myFont);
cijena=new JLabel("Unesi cijenu");cijena.setFont(myFont);
txtcijena=new JTextField(15);txtcijena.setFont(myFont);
potvrdi=new JButton("Potvrdi");potvrdi.setFont(myFont);
odustani=new JButton("odustani");odustani.setFont(myFont);
panel.add(sifra);
panel.add(txtsifra);
panel.add(artikl);
panel.add(txtartikl);
panel.add(mjera);
panel.add(txtmjera);
panel.add(kolicina);
panel.add(txtkolicina);
panel.add(pdv);
panel.add(txtpdv);
panel.add(cijena);
panel.add(txtcijena);


panel.add(potvrdi);
panel.add(odustani);



primka.add(panel);
primka.setSize(400,400);
primka.setVisible(true);



odustani.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
  primka.dispose();
  }
  }); 

potvrdi.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 potvrdi();
  }
  }); 

primka.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
           primka.dispose();
         }        
      });   
}



public  void potvrdi()
{

Connection c = null;
    Statement stmt = null;
int txtsifrax=Integer.parseInt(txtsifra.getText().toString());
String txtartiklx=txtartikl.getText().toString();
float txtmjerax=Float.parseFloat(txtmjera.getText().toString());
float txtkolicinax=Float.parseFloat(txtkolicina.getText().toString());
float txtpdvx=Float.parseFloat(txtpdv.getText().toString());
float txtcijenax=Float.parseFloat(txtcijena.getText().toString());
 try {
      Class.forName("org.sqlite.JDBC");
      c = DriverManager.getConnection("jdbc:sqlite:basa.db");
      
      System.out.println("Opened database successfully");

      stmt = c.createStatement();


 String sql = "INSERT INTO skladiste3 (id,naziv,mjera,kolicina,pdv,cijena) " +
              "VALUES ("+txtsifrax+",'"+txtartiklx+"',"+txtmjerax+","+txtkolicinax+","+txtpdvx+","+txtcijenax +");"; 
stmt.executeUpdate(sql);



stmt.close();
     
      c.close();
    } catch ( Exception e ) {
      System.err.println( e.getMessage() );
     JOptionPane.showMessageDialog(primka, "Ukucana sifra");
//System.exit(0);
    }
    System.out.println("Records created successfully");
  }


}

/////////////////////////////////////////////skladisnica

class skladisnica {
JFrame skladisnica;
JPanel panel;
JLabel sifra,kolicina;
JButton potvrdi,odustani;
JTextField txtsifra,txtkolicina;
public skladisnica()
{
skladisnica=new JFrame("skladisnica");
panel = new JPanel();
panel.setBackground(Color.gray);
GridLayout layout = new GridLayout(3,2,30,20);
panel.setLayout(layout);
Font myFont = new Font("Serif", Font.ITALIC | Font.BOLD, 16);
panel.setFont(myFont);

sifra=new JLabel("Unesi sifru");sifra.setFont(myFont);
txtsifra=new JTextField(15);txtsifra.setFont(myFont);
kolicina=new JLabel("Unesi kolicinu");kolicina.setFont(myFont);
txtkolicina=new JTextField(15);txtkolicina.setFont(myFont);

potvrdi=new JButton("Potvrdi");potvrdi.setFont(myFont);
odustani=new JButton("odustani");odustani.setFont(myFont);


panel.add(kolicina);
panel.add(txtkolicina);
panel.add(sifra);
panel.add(txtsifra);

panel.add(potvrdi);
panel.add(odustani);

skladisnica.add(panel);


skladisnica.setSize(400,150);
skladisnica.setVisible(true);

odustani.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
  skladisnica.dispose();
  }
  }); 

potvrdi.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
  potvrdix();
  }
  }); 





skladisnica.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
           skladisnica.dispose();
         }        
      });   
}


public void potvrdix(){

Connection c = null;
Statement stmt = null;
int txtsifrax=Integer.parseInt(txtsifra.getText().toString());
float txtkolicinax=Float.parseFloat(txtkolicina.getText().toString());
try {
      Class.forName("org.sqlite.JDBC");
      c = DriverManager.getConnection("jdbc:sqlite:basa.db");
      
      System.out.println("Opened database successfully");

      stmt = c.createStatement();

String str="SELECT * FROM skladiste3 where id="+txtsifrax+";";

ResultSet rs = stmt.executeQuery(str);
rs.next();
String[] t=new String[6];
//t[0]=rs.getString(1);
//t[1]=rs.getString(2);
//t[2]=rs.getString(3);
t[3]=rs.getString(4);
//t[3]=rs.getString(5);
//t[4]=rs.getString(6);

float txtkolicinab=0.0f;


try {
txtkolicinab=Float.parseFloat(t[3]);

} catch ( Exception ex ) {
      System.err.println( ex.getMessage() );
}

txtkolicinab=txtkolicinab+txtkolicinax;

String sqlx = "UPDATE skladiste3 set kolicina="+txtkolicinab+" where id="+txtsifrax+";";
stmt.executeUpdate(sqlx);



stmt.close();
c.close();

    } catch ( Exception e ) {
      System.err.println( e.getMessage() );
      System.exit(0);
    }
    System.out.println("Records created successfully");
  }




}




/////////////////////////////////////////////skladiste

class skladiste {
JFrame skladiste;
 
public skladiste()
{
skladiste=new JFrame("skladiste");
JPanel panel = new JPanel();
Vector<Vector> data = new Vector<Vector>();
Connection c = null;
    Statement st = null;
Vector<String> col = new Vector<String>();
try {
      Class.forName("org.sqlite.JDBC");
      c = DriverManager.getConnection("jdbc:sqlite:basa.db");
 st = c.createStatement();
ResultSet rs = st.executeQuery("SELECT * FROM skladiste3 order by id asc;");
ResultSetMetaData rsMetaData = rs.getMetaData();
    int numberOfColumns = rsMetaData.getColumnCount();
for (int ii = 1; ii < numberOfColumns + 1; ii++) 
      col.addElement(rsMetaData.getColumnName(ii));

while (rs.next()) {
Vector<String> t= new Vector<String>();
      
        t.addElement(rs.getString(1));
        t.addElement(rs.getString(2));
        t.addElement(String.format("%.3f",Float.parseFloat(rs.getString(3))));
        t.addElement(String.format("%.3f",Float.parseFloat(rs.getString(4))));
        t.addElement(String.format("%.2f",Float.parseFloat(rs.getString(5))));
        t.addElement(String.format("%.2f",Float.parseFloat(rs.getString(6))));
data.addElement(t);
    }
 
rs.close();
    st.close();
 c.close();
    } catch (Exception e ) {
      System.err.println( e.getMessage() );
      System.exit(0);
    }

DefaultTableModel model  = new DefaultTableModel(data,col); 


JTable table = new JTable(model);
alignRight(table,0);
alignRight(table,2);
alignRight(table,3);
alignRight(table,4);
alignRight(table,5);


JTableHeader header = table.getTableHeader();
JScrollPane pane = new JScrollPane(table);
  skladiste.add(pane);



//skladiste.add(panel);


skladiste.setSize(400,400);
skladiste.setVisible(true);
skladiste.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
           skladiste.dispose();
         }        
      }); 
  
}
private void alignRight(JTable table, int column) {
    DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
    rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
    table.getColumnModel().getColumn(column).setCellRenderer(rightRenderer);
}

}

////////////////////////////////////djelatnici
class djelatnici {
JFrame djelatnici;
JPanel panel;
JLabel id_djelatnika,oib,ime,prezime,zaporka;
JTextField id_djelatnikatxt,oibtxt,imetxt,prezimetxt,zaporkatxt;
JButton potvrdi,odustani;
public djelatnici()
{
djelatnici=new JFrame("djelatnici");

panel = new JPanel();
panel.setBackground(Color.gray);
GridLayout layout = new GridLayout(6,2,30,20);
panel.setLayout(layout);
Font myFont = new Font("Serif", Font.ITALIC | Font.BOLD, 16);
panel.setFont(myFont);

id_djelatnika=new JLabel("Unesi id_djelanika");id_djelatnika.setFont(myFont);
id_djelatnikatxt=new JTextField(15);id_djelatnikatxt.setFont(myFont);
oib=new JLabel("Unesi oib");oib.setFont(myFont);
oibtxt=new JTextField(15);oibtxt.setFont(myFont);
ime=new JLabel("Unesi ime");ime.setFont(myFont);
imetxt=new JTextField(15);imetxt.setFont(myFont);
prezime=new JLabel("Unesi prezime");prezime.setFont(myFont);
prezimetxt=new JTextField(15);prezimetxt.setFont(myFont);
zaporka=new JLabel("Unesi zaporku");zaporka.setFont(myFont);
zaporkatxt=new JTextField(15);zaporkatxt.setFont(myFont);
potvrdi=new JButton("Potvrdi");potvrdi.setFont(myFont);
odustani=new JButton("odustani");odustani.setFont(myFont);
panel.add(id_djelatnika);
panel.add(id_djelatnikatxt);
panel.add(oib);
panel.add(oibtxt);
panel.add(ime);
panel.add(imetxt);
panel.add(prezime);
panel.add(prezimetxt);
panel.add(zaporka);
panel.add(zaporkatxt);

panel.add(potvrdi);
panel.add(odustani);



djelatnici.add(panel);
djelatnici.setSize(400,400);
djelatnici.setVisible(true);



odustani.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
  djelatnici.dispose();
  }
  }); 

potvrdi.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent ae){
 potvrdi();
  }
  }); 

djelatnici.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
           djelatnici.dispose();
         }        
      });   
}



public  void potvrdi()
{

Connection c = null;
    Statement stmt = null;
int xid_djelatnikatxt=Integer.parseInt(id_djelatnikatxt.getText().toString());
String xoibtxt=oibtxt.getText().toString();
String ximetxt=imetxt.getText().toString();
String xprezimetxt=prezimetxt.getText().toString();
String xzaporkatxt=zaporkatxt.getText().toString();
 try {
      Class.forName("org.sqlite.JDBC");
      c = DriverManager.getConnection("jdbc:sqlite:basa.db");
      
      System.out.println("Opened database successfully");

      stmt = c.createStatement();

 String sql = "INSERT INTO djelatnici (id_djelatnik,oib,ime,prezime,zaporka) " +
              "VALUES ("+xid_djelatnikatxt+",'"+xoibtxt+"','"+ximetxt+"','"+xprezimetxt+"','"+xzaporkatxt+"');"; 
stmt.executeUpdate(sql);



stmt.close();
     
      c.close();
    } catch ( Exception e ) {
      System.err.println( e.getMessage() );
     JOptionPane.showMessageDialog(djelatnici, "Greska");
//System.exit(0);
    }
    System.out.println("Records created successfully");
  }


}




/////////////////////////////////////////////blagajna

class blagajna {
String Date=null;
String Time=null;
String rbx=null;
String ime=null;
String prezime=null;
String blagajnik=null;
int id_djelatnik;
JFrame blagajna;
JLabel label1,label3;
JTextField txtkolicinaa=new JTextField(15);
JTextField txtsifraa=new JTextField(15);
JPanel panelx; 
int txtsifrax;
float suma,suma13,suma25;
DateFormat dateFormat;
DateFormat timeFormat;
Date time;
JLabel buton1;
JLabel buton2;
JLabel buton3;
JLabel buton4;
boolean s13=false,s25=false;
JScrollPane scrollPane;
String ss="";
int isi=0,ixi=0,siks=0;
float iks=0.0f,piks=0.0f;
boolean pip=false;
public blagajna(String ime,String prezime,int id_djelatnik)
{
this.ime=ime;
this.prezime=prezime;
this.id_djelatnik=id_djelatnik;
blagajna=new JFrame("blagajna");
blagajna.setSize(500,400);
GridLayout layout = new GridLayout(0,3);
JPanel panel1 = new JPanel();
panel1.setPreferredSize(new Dimension(120, 70));
layout.setHgap(10);
layout.setVgap(10);
      
      panel1.setLayout(layout);
       label1=new JLabel("RACUN",JLabel.CENTER);

GridLayout layout1 = new GridLayout(0,3);
panel1.setLayout(layout1);
       
       panelx=new JPanel(); 
       label3=new JLabel("PROX1",JLabel.CENTER);
Font myFont = new Font("Serif", Font.ITALIC | Font.BOLD, 20);
label3.setFont(myFont);


panel1.add(label1);
panel1.add(panelx);
panel1.add(label3);


dateFormat = new SimpleDateFormat("dd/MM/yyyy");
timeFormat = new SimpleDateFormat("HH:mm:ss");

time = new Date();
Date = dateFormat.format(time);
Time = timeFormat.format(time);

      panelx.setBackground(Color.gray);
     GridLayout layoutx = new GridLayout(4,1);
      layout.setHgap(10);
      layout.setVgap(10);
      
      panelx.setLayout(layoutx);
blagajnik=ime+" "+prezime+"("+id_djelatnik+")";
buton1=new JLabel("Racun");        
buton2=new JLabel(Date); 
buton3=new JLabel(Time); 
buton4=new JLabel(blagajnik);    
    
    panelx.add(buton1);
    panelx.add(buton2);
    panelx.add(buton3);
    panelx.add(buton4);

JPanel panel = new JPanel();
JPanel panel2 = new JPanel(new FlowLayout());
  String data[][] = null;
  String col[] = {"Sifra","Artikl","Kolicina","PDV","Cijena","Iznos"};
final  DefaultTableModel model = new DefaultTableModel(data,col){
      public boolean isCellEditable(int rowIndex, int mColIndex) {
        return false;
      }
    };
final JTable table = new JTable(model);
    scrollPane = new JScrollPane(table);
panel.add(scrollPane);
DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
    rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
    table.getColumnModel().getColumn(0).setCellRenderer(rightRenderer);
    table.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
    table.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
    table.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
    table.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);

    table.addKeyListener(new KeyListener(){

public void keyTyped(KeyEvent e) {

    char c = e.getKeyChar();
if(c!=KeyEvent.VK_ENTER){
pip=true;
iks=0.0f;
ss+=""+c;
isi=Integer.parseInt(ss);
System.out.println("Key Typed: " +isi );
}}
public void keyPressed(KeyEvent e) {}
public void keyReleased(KeyEvent e) {}
});

suma=0.0f;
  suma13=0.0f;
  suma25=0.0f;


 Action printAction4 = new AbstractAction(){
      public void actionPerformed(ActionEvent e) {
System.out.println("enter");


Connection c = null;
    Statement stmt = null;
    
try {
Class.forName("org.sqlite.JDBC");
c = DriverManager.getConnection("jdbc:sqlite:basa.db");
stmt = c.createStatement();

String str="SELECT * FROM skladiste3 where id="+isi+";";
ResultSet rs = stmt.executeQuery(str);
rs.next();
iks++;
//
String[] t=new String[6];
t[0]=rs.getString(1);
t[1]=rs.getString(2);
t[2]=String.format("%.2f",iks);
t[3]=String.format("%.2f",Float.parseFloat(rs.getString(5)));
t[4]=String.format("%.2f",Float.parseFloat(rs.getString(6)));
piks=iks*Float.parseFloat(rs.getString(6));
t[5]=String.format("%.2f",piks);

if(pip){
model.addRow(t);
pip=false;
siks++;
}
model.setValueAt(iks, siks-1, 2);
model.setValueAt(t[5], siks-1, 5);

suma=suma+Float.parseFloat(rs.getString(6));
if(Float.parseFloat(rs.getString(5))==13.0f)
{ suma13=suma13+Float.parseFloat(rs.getString(6));
s13=true;
}
if(Float.parseFloat(rs.getString(5))==25.0f)
{ suma25=suma25+Float.parseFloat(rs.getString(6));
s25=true;
}
label3.setText(String.format("%.2f",suma));

stmt.close();
     
      c.close();
    } catch ( Exception ex ) {
      System.err.println( ex.getMessage() );
      //System.exit(0);
    }

 //isi=0;
ss="";   

}};

String ACTION_KEY1 = "theAction1";  
//scrollPane.addActionListener(printAction4);
KeyStroke space1 = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, true);
    InputMap inputMap1 = table.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
    inputMap1.put(space1, ACTION_KEY1);
    ActionMap actionMap1 = table.getActionMap();
    actionMap1.put(ACTION_KEY1, printAction4);
    table.setActionMap(actionMap1); 
  




  


JButton button1 = new JButton("Stisni");
JButton button2 = new JButton("Obrisi");
ActionListener printAction1 = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
  
Connection c = null;
    Statement stmt = null;
    
try {
Class.forName("org.sqlite.JDBC");
c = DriverManager.getConnection("jdbc:sqlite:basa.db");
stmt = c.createStatement();

float txtkolicinaaa=0.0f;
float sumx=0.0f;

txtkolicinaaa=Float.parseFloat(txtkolicinaa.getText().toString());
txtsifrax=Integer.parseInt(txtsifraa.getText().toString());
siks++;

String str="SELECT * FROM skladiste3 where id="+txtsifrax+";";

ResultSet rs = stmt.executeQuery(str);
rs.next();
String[] t=new String[6];
t[0]=rs.getString(1);
t[1]=rs.getString(2);
t[2]=String.format("%.2f",txtkolicinaaa);
//t[3]=rs.getString(4);
t[3]=String.format("%.2f",Float.parseFloat(rs.getString(5)));
t[4]=String.format("%.2f",Float.parseFloat(rs.getString(6)));

sumx=Float.parseFloat(t[4])*txtkolicinaaa;

//t[5]=Float.toString(sumx);
t[5]=String.format("%.2f",sumx);
suma=suma+sumx;
if(Float.parseFloat(rs.getString(5))==13.0f)
{ suma13=suma13+sumx;
s13=true;
}
if(Float.parseFloat(rs.getString(5))==25.0f)
{ suma25=suma25+sumx;
s25=true;
}

model.addRow(t);
//label3.setText(Float.toString(suma));
label3.setText(String.format("%.2f",suma));       

//float fk=Float.parseFloat(rs.getString(4))-txtkolicinaaa;
//String sql = "UPDATE skladiste3 set kolicina="+fk+" where id="+txtsifrax+";";
//stmt.executeUpdate(sql);

 stmt.close();
     
      c.close();
    } catch ( Exception ex ) {
      System.err.println( ex.getMessage() );
      System.exit(0);
    }

button2.requestFocus();
      }
    };
    button1.addActionListener(printAction1);
  


 ActionListener printAction2 = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
while( model.getRowCount() > 0 ){
        model.removeRow(0);
    }
suma=0;
suma13=0;
suma25=0;
s13=false;
s25=false;
siks=0;
time = new Date();
Date = dateFormat.format(time);
Time = timeFormat.format(time);
buton2.setText(Date); 
buton3.setText(Time);


}
};
button2.addActionListener(printAction2);


//racun
 
JButton button3 = new JButton("Print");
    Action printAction3 = new AbstractAction(){
      public void actionPerformed(ActionEvent e) {


 Connection c = null;
    Statement stmt = null;
    
try {
Class.forName("org.sqlite.JDBC");
c = DriverManager.getConnection("jdbc:sqlite:basa.db");
stmt = c.createStatement();

//String str="SELECT * FROM skladiste3;";
//ResultSet rs = stmt.executeQuery(str);
//rs.next();

if(model.getRowCount()==0)
{
JOptionPane.showMessageDialog(blagajna, "Nije ukucan niti jedan artikl");
}else
{
for(int pi=0;pi<= model.getRowCount()-1;pi++){
String x0=model.getValueAt(pi, 0).toString();
String x2=model.getValueAt(pi, 2).toString();
String str="SELECT * FROM skladiste3 where id="+Integer.parseInt(x0)+";";
ResultSet rs = stmt.executeQuery(str);
rs.next();
float fk=0.0f;
String sql=null;
float fpdv=Float.parseFloat(rs.getString(5));
float fm=Float.parseFloat(rs.getString(3));
if(fpdv==13.0f && fm!=0.007f)
{
fk=Float.parseFloat(rs.getString(4))-Float.parseFloat(x2);
sql = "UPDATE skladiste3 set kolicina="+fk+" where id="+Integer.parseInt(x0)+";";
stmt.executeUpdate(sql);
}
if(fpdv==13.0f && fm==0.007f)
{
fk=Float.parseFloat(rs.getString(4))-(0.007f*Float.parseFloat(x2));
sql = "UPDATE skladiste3 set kolicina="+fk+" where id="+Integer.parseInt(x0)+";";
stmt.executeUpdate(sql);
}
if(fpdv==25.0f  && fm==0.03f)
{
fk=Float.parseFloat(rs.getString(4))-(0.03f*Float.parseFloat(x2));
sql = "UPDATE skladiste3 set kolicina="+fk+" where id="+Integer.parseInt(x0)+";";
stmt.executeUpdate(sql);
int i1=Integer.parseInt(x0)+1;
String str1="SELECT * FROM skladiste3 where id="+i1+";";
rs = stmt.executeQuery(str1);
rs.next();
float fk1=Float.parseFloat(rs.getString(4))-(0.03f*Float.parseFloat(x2));
sql = "UPDATE skladiste3 set kolicina="+fk1+" where id="+i1+";";
stmt.executeUpdate(sql);
}
if(fpdv==25.0f && fm==0.05f)
{
fk=Float.parseFloat(rs.getString(4))-(0.05f*Float.parseFloat(x2));
sql = "UPDATE skladiste3 set kolicina="+fk+" where id="+Integer.parseInt(x0)+";";
stmt.executeUpdate(sql);
int i1=Integer.parseInt(x0)-1;
String str1="SELECT * FROM skladiste3 where id="+i1+";";
rs = stmt.executeQuery(str1);
rs.next();
float fk1=Float.parseFloat(rs.getString(4))-(0.05f*Float.parseFloat(x2));
sql = "UPDATE skladiste3 set kolicina="+fk1+" where id="+i1+";";
stmt.executeUpdate(sql);
}


//model.removeRow(0);
}

//float fk=Float.parseFloat(rs.getString(4))-txtkolicinaaa;
//String sql = "UPDATE skladiste3 set kolicina="+fk+" where id="+txtsifrax+";";
//stmt.executeUpdate(sql);

time = new Date();
Date = dateFormat.format(time);
Time = timeFormat.format(time);
buton2.setText(Date); 
buton3.setText(Time);

DateFormat dateFormat1= new SimpleDateFormat("yy");
String Date1 = dateFormat1.format(time);


String strx="SELECT count(*) FROM racun;";
ResultSet rsi = stmt.executeQuery(strx);
rsi.next();;
int rb=rsi.getInt(1);
rb++;
rbx=String.format("%04d",rb)+"/"+Date1;
buton1.setText(rbx);
String sqli = "INSERT INTO racun (id_racun,datum,vrijeme) VALUES ("+rb+",'"+Date+"','"+Time+"');"; 
stmt.executeUpdate(sqli);
}



 stmt.close();
     
      c.close();
    } catch ( Exception ex ) {
      System.err.println( ex.getMessage() );
      System.exit(0);
    }


label3.setText(String.format("%.2f",suma));
//label3.setText(Float.toString(suma));
soap sb=new soap();
String str=null;
try{
str=sb.returnsoap();
}catch(Exception ex)
{System.out.println(ex.toString());} 
new printer(model,Date,Time,suma,suma13,suma25,s13,s25,rbx,str,blagajnik);
suma=0;
suma13=0;
suma25=0;
s13=false;
s25=false;

//DefaultTableModel model = (DefaultTableModel) table.getModel();
    while( model.getRowCount() > 0 ){
        model.removeRow(0);
    }


  }
};
 String ACTION_KEY = "theAction";  
button3.addActionListener(printAction3);
KeyStroke space = KeyStroke.getKeyStroke(' ');
    InputMap inputMap = button3.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
    inputMap.put(space, ACTION_KEY);
    ActionMap actionMap = button3.getActionMap();
    actionMap.put(ACTION_KEY, printAction3);
    button3.setActionMap(actionMap); 

panel2.add(txtkolicinaa);
panel2.add(txtsifraa);
panel2.add(button1);
panel2.add(button2);
panel2.add(button3);

blagajna.add(scrollPane, BorderLayout.CENTER);
blagajna.add(panel1, BorderLayout.NORTH);
blagajna.add(panel2, BorderLayout.SOUTH);

blagajna.setSize(600,400);
blagajna.setVisible(true);


blagajna.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
           blagajna.dispose();
         }        
      });   
}}

///////////////////////////////////////////////////soap

class soap{
SOAPMessage rp;

public soap()
{
try {
// Create the connection
SOAPConnectionFactory myFct = SOAPConnectionFactory.newInstance();
SOAPConnection myCon = myFct.createConnection();

// Create message
MessageFactory myMsgFct = MessageFactory.newInstance();
SOAPMessage message = myMsgFct.createMessage();

// Add eventually a SoapAction header if necessary
        /*
        MimeHeaders hd = msg.getMimeHeaders();
        hd.addHeader("SOAPAction", "urn:hellowsdl#hello");
        */


// Object for message parts
SOAPPart mySPart = message.getSOAPPart();
SOAPEnvelope myEnvp = mySPart.getEnvelope();

SOAPBody body = myEnvp.getBody();

Name bodyName = myEnvp.createName("hello","m","urn:hellowsdl");
SOAPBodyElement gltp = body.addBodyElement(bodyName);

Name myContent = myEnvp.createName("name");
SOAPElement mySymbol = gltp.addChildElement(myContent);


mySymbol.addTextNode("igor");



// Save message
	message.saveChanges();


	String urlval = "http://master44.eu5.org/vjezbe/serverx6.php?wsdl";
        // or /rcx-ws-rpc/rcx for my rpc/encoded web service

	rp = myCon.call(message, urlval);



  myCon.close();
 
     

	

      }
      catch (Exception e){
	System.out.println(e.getMessage());
      }
 


}

public String returnsoap() throws Exception
{
 SOAPPart sp = rp.getSOAPPart();
      SOAPEnvelope se = sp.getEnvelope();
      SOAPBody sb = se.getBody();
 Iterator it = sb.getChildElements();
    
        SOAPBodyElement bodyElement = (SOAPBodyElement) it.next();
        Iterator it2 = bodyElement.getChildElements();
        
            SOAPElement element2 = (SOAPElement) it2.next();
            return element2.getValue();

}


}



////////////////////////////////////////////////////printer


class printer implements Printable {
DefaultTableModel model;
JobAttributes  theJobAttribs;
PrinterJob printJob;
String Date=null,Time=null,rbx=null,str=null,blagajnik=null;
float suma,suma13,suma25;
boolean s13,s25;

public printer(DefaultTableModel model,String Date,String Time,float suma,float suma13,float suma25,boolean s13,boolean s25,String rbx,String str,String blagajnik) {
this.model=model;
this.Date=Date;
this.Time=Time;
this.suma=suma;
this.suma13=suma13;
this.suma25=suma25;
this.s13=s13;
this.s25=s25;
this.rbx=rbx;
this.str=str;
this.blagajnik=blagajnik;
theJobAttribs  = new JobAttributes();  
theJobAttribs.setDialog(JobAttributes.DialogType.NONE);
printJob = PrinterJob.getPrinterJob();
printJob.setPrintable(this);

      try {
        printJob.print();
      } catch (PrinterException e) {
      }
    


}

public int print(Graphics g, PageFormat Pf, int pageIndex) throws PrinterException {
    if (pageIndex > 0)
      return NO_SUCH_PAGE;
    Graphics2D g2d = (Graphics2D) g;
    g2d.translate(Pf.getImageableX(), Pf.getImageableY());
    Line2D.Double line = new Line2D.Double();
  
    g2d.setPaint(Color.cyan);
    line.setLine(0, 0,227 , 0);
    g2d.draw(line);

    line.setLine(0, 0,0 , 300);
    g2d.draw(line);

    line.setLine(227, 0,227 , 300);
    g2d.draw(line);
    g2d.setFont(new Font( "Monospaced", Font.PLAIN, 10 ));
    g2d.drawString("           Caffe kod praseta", 0, 12);
    g2d.drawString("OIB: 13622566541 ", 0, 24);
    g2d.drawString("RACUN "+rbx, 0, 36);
    g2d.drawString(Date, 90, 36);
    g2d.drawString(Time, 170, 36);
    g2d.drawString("Blagajnik: "+blagajnik,0,48);
    g2d.drawString("Naziv       Kolicina  Cijena    Iznos", 0, 60);
    g2d.drawString("-------------------------------------", 0, 72);
int u=0;
for(int si=0;si<= model.getRowCount()-1;si++){
String xx=model.getValueAt(si, 1).toString();
String yy=model.getValueAt(si, 2).toString();
String zz=model.getValueAt(si, 4).toString();
String tt=model.getValueAt(si, 5).toString();
int px=xx.length();
int py=yy.length();
int pz=zz.length();
int pt=tt.length();
if(px<=12){
 for (int ii = 0; ii <12-px; ii++) {
       xx =xx+" ";   
  }}
else {
xx = xx.substring(0, 12);
}
if(py<=5){
 for (int ii = 0; ii <5-py; ii++) {
       yy=" "+yy;   
  }}
if(pz<=5){
 for (int ii = 0; ii <5-pz; ii++) {
       zz=" "+zz;   
  }}
if(pt<=5){
 for (int ii = 0; ii <5-pt; ii++) {
       tt=" "+tt;   
  }}
System.out.print(xx+" "+yy);
System.out.println(zz);
g2d.drawString(xx+"   "+yy+"   "+zz+"    "+tt, 0, 84+u);
u+=12;
 }
 
g2d.drawString("=====================================", 0, 84+u);
String uu=String.format("%.2f",suma);
int pt=uu.length();
if(pt<=6){
 for (int ii = 0; ii <6-pt; ii++) {
       uu=" "+uu;   
  }}
g2d.drawString("                       Ukupno  "+uu, 0, 96+u);
g2d.drawString("Rekapitulacija                 ", 0, 108+u);
g2d.drawString("Stopa    Osnovica    Porez      Iznos", 0, 120+u); 
g2d.drawString("-------------------------------------", 0, 132+u);
float suma13x=suma13/1.13f;
float suma13y=suma13-suma13x;
float suma25x=suma25/1.25f;
float suma25y=suma25-suma25x;
String ux=String.format("%.2f",suma13x);
int pxx=ux.length();
String uy=String.format("%.2f",suma13y);
int pyy=uy.length();
String vx=String.format("%.2f",suma25x);
int dxx=vx.length();
String vy=String.format("%.2f",suma25y);
int dyy=vy.length();
String uyy=String.format("%.2f",suma13);
int byy=uyy.length();
String vxx=String.format("%.2f",suma25);
int bxx=vxx.length();

if(byy<=6){
 for (int ii = 0; ii <6-byy; ii++) {
       uyy=" "+uyy;   
  }}
if(bxx<=6){
 for (int ii = 0; ii <6-bxx; ii++) {
       vxx=" "+vxx;   
  }}
if(pxx<=6){
 for (int ii = 0; ii <6-pxx; ii++) {
       ux=" "+ux;   
  }}
if(pyy<=6){
 for (int ii = 0; ii <6-pyy; ii++) {
       uy=" "+uy;   
  }}
if(dxx<=6){
 for (int ii = 0; ii <6-dxx; ii++) {
       vx=" "+vx;   
  }}
if(dyy<=6){
 for (int ii = 0; ii <6-dyy; ii++) {
       vy=" "+vy;   
  }}
if(s13 && !s25){
g2d.drawString("13.0%"+"      "+ux+"   "+uy+"     "+uyy, 0, 144+u);
g2d.drawString("-------------------------------------", 0, 156+u);
g2d.drawString("                       Ukupno  "+uu, 0, 168+u);
  }
if(s25 && !s13){
g2d.drawString("25.0%"+"      "+vx+"   "+vy+"     "+vxx, 0, 144+u);
g2d.drawString("-------------------------------------", 0, 156+u);
g2d.drawString("                       Ukupno  "+uu, 0, 168+u);
}
if(s13 && s25){
g2d.drawString("13.0%"+"      "+ux+"   "+uy+"     "+uyy, 0, 144+u);
g2d.drawString("25.0%"+"      "+vx+"   "+vy+"     "+vxx, 0, 156+u);
g2d.drawString("-------------------------------------", 0, 168+u);
g2d.drawString("                       Ukupno  "+uu, 0, 180+u);



}


g2d.drawString("     "+str,0,200+u);

    return PAGE_EXISTS;
  }


}







